import { Button } from "@/components/ui/button";
import { Heart, Search, Filter, Star, Sparkles, Instagram } from "lucide-react";
import { useState, useMemo } from "react";

interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  image: string;
  description: string;
  rating: number;
  reviews: number;
}

const products: Product[] = [
  {
    id: 1,
    name: "كابتشينو",
    category: "مشروبات",
    price: 2.5,
    image: "/manus-storage/cappuccino_knouf_64bac58e.png",
    description: "كابتشينو كريمي مع لاتيه آرت جميل",
    rating: 4.8,
    reviews: 142,
  },
  {
    id: 2,
    name: "لاتيه",
    category: "مشروبات",
    price: 2.75,
    image: "/manus-storage/latte_knouf_72e91b70.png",
    description: "لاتيه ناعم مع طبقات حليب مثالية",
    rating: 4.9,
    reviews: 156,
  },
  {
    id: 3,
    name: "أمريكانو",
    category: "مشروبات",
    price: 2.0,
    image: "/manus-storage/americano_knouf_745e45ea.png",
    description: "إسبريسو غني مع ماء ساخن",
    rating: 4.7,
    reviews: 98,
  },
  {
    id: 4,
    name: "موكا",
    category: "مشروبات",
    price: 3.25,
    image: "/manus-storage/mocha_knouf_2dfb0bac.png",
    description: "موكا فاخر مع شوكولاتة وكريمة",
    rating: 4.9,
    reviews: 189,
  },
  {
    id: 5,
    name: "ماكياتو",
    category: "مشروبات",
    price: 2.5,
    image: "/manus-storage/macchiato_knouf_46401cf6.png",
    description: "إسبريسو مع رغوة حليب ناعمة",
    rating: 4.8,
    reviews: 127,
  },
  {
    id: 6,
    name: "كرواسان",
    category: "مخبوزات",
    price: 1.75,
    image: "/manus-storage/croissant_knouf_449e7d3a.png",
    description: "كرواسان زبدة فلاكي طازج",
    rating: 4.9,
    reviews: 203,
  },
  {
    id: 7,
    name: "دونات",
    category: "مخبوزات",
    price: 1.5,
    image: "/manus-storage/donut_knouf_93c4716d.png",
    description: "دونات مزججة بالشوكولاتة والذهب",
    rating: 4.7,
    reviews: 165,
  },
  {
    id: 8,
    name: "كوكيز",
    category: "مخبوزات",
    price: 1.25,
    image: "/manus-storage/cookies_knouf_dedcb386.png",
    description: "كوكيز الشوكولاتة مع رقائق ذهبية",
    rating: 4.8,
    reviews: 134,
  },
];

const categories = ["الكل", "مشروبات", "مخبوزات"];

export default function Home() {
  const [favorites, setFavorites] = useState<Set<number>>(new Set());
  const [selectedCategory, setSelectedCategory] = useState("الكل");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("featured");

  const filteredProducts = useMemo(() => {
    let filtered = products;

    if (selectedCategory !== "الكل") {
      filtered = filtered.filter((p) => p.category === selectedCategory);
    }

    if (searchQuery) {
      filtered = filtered.filter(
        (p) =>
          p.name.includes(searchQuery) ||
          p.description.includes(searchQuery)
      );
    }

    if (sortBy === "price-low") {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sortBy === "price-high") {
      filtered.sort((a, b) => b.price - a.price);
    } else if (sortBy === "rating") {
      filtered.sort((a, b) => b.rating - a.rating);
    }

    return filtered;
  }, [selectedCategory, searchQuery, sortBy]);

  const toggleFavorite = (id: number) => {
    const newFavorites = new Set(favorites);
    if (newFavorites.has(id)) {
      newFavorites.delete(id);
    } else {
      newFavorites.add(id);
    }
    setFavorites(newFavorites);
  };

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Animated background elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-20 right-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-40 left-10 w-96 h-96 bg-muted/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/70 backdrop-blur-xl border-b border-border/30 shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary via-primary/80 to-muted flex items-center justify-center shadow-lg">
              <span className="text-xl font-bold text-primary-foreground">K</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">knof</h1>
              <p className="text-xs text-muted-foreground">قهوة فاخرة حرفية</p>
            </div>
          </div>

          {/* Search bar */}
          <div className="hidden md:flex items-center gap-2 bg-muted/30 rounded-full px-4 py-2 backdrop-blur-sm border border-border/20">
            <Search className="w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="ابحث عن منتج..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent text-sm text-foreground placeholder-muted-foreground outline-none w-40"
            />
          </div>

          <nav className="hidden md:flex items-center gap-8">
            <a href="#" className="text-sm font-medium text-foreground hover:text-primary transition-colors duration-300">
              الرئيسية
            </a>
            <a href="#products" className="text-sm font-medium text-foreground hover:text-primary transition-colors duration-300">
              المنيو
            </a>
            <a href="#about" className="text-sm font-medium text-foreground hover:text-primary transition-colors duration-300">
              عن الموقع
            </a>
          </nav>

          <a
            href="https://www.instagram.com/knof.kw?igsh=MXhiczV2aTU5eHhuNw=="
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 hover:bg-muted/50 rounded-full transition-all duration-300"
          >
            <Instagram className="w-6 h-6 text-primary hover:text-primary/80 transition-colors" />
          </a>
        </div>
      </header>



      {/* Products Section */}
      <section id="products" className="py-24 relative">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-6xl font-bold text-foreground mb-4">
              منيو knof
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              اختر من مجموعتنا الواسعة من المشروبات والمخبوزات الطازجة المصنوعة يومياً بعناية فائقة
            </p>
          </div>

          {/* Filters and Search */}
          <div className="mb-12 space-y-6">
            {/* Mobile Search */}
            <div className="md:hidden flex items-center gap-2 bg-muted/30 rounded-full px-4 py-3 backdrop-blur-sm border border-border/20">
              <Search className="w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="ابحث..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent text-sm text-foreground placeholder-muted-foreground outline-none flex-1"
              />
            </div>

            {/* Category and Sort */}
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <div className="flex gap-3 flex-wrap">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-6 py-2 rounded-full font-semibold transition-all duration-300 ${
                      selectedCategory === cat
                        ? "bg-gradient-to-r from-primary to-muted text-primary-foreground shadow-lg shadow-primary/30"
                        : "bg-muted/30 text-foreground hover:bg-muted/50 border border-border/20"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2 bg-muted/30 rounded-full px-4 py-2 backdrop-blur-sm border border-border/20">
                <Filter className="w-4 h-4 text-muted-foreground" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-transparent text-sm text-foreground outline-none cursor-pointer"
                >
                  <option value="featured">الأكثر شهرة</option>
                  <option value="rating">الأعلى تقييماً</option>
                  <option value="price-low">السعر: الأقل أولاً</option>
                  <option value="price-high">السعر: الأعلى أولاً</option>
                </select>
              </div>
            </div>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product, index) => (
              <div
                key={product.id}
                className="group relative bg-card rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-3 border border-border/30 backdrop-blur-sm"
                style={{
                  animation: `fadeInUp 0.6s ease-out ${index * 0.1}s both`,
                }}
              >
                {/* Product Image */}
                <div className="relative w-full aspect-square bg-gradient-to-br from-muted/50 to-primary/20 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-4/5 h-4/5 object-cover transition-transform duration-500 group-hover:scale-110 mx-auto my-auto"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                  {/* Badge */}
                  <div className="absolute top-3 right-3 bg-gradient-to-r from-primary to-muted text-primary-foreground px-3 py-1 rounded-full text-xs font-bold shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    ⭐ {product.rating}
                  </div>
                </div>

                {/* Product Info */}
                <div className="p-5 space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <h3 className="text-lg font-bold text-foreground group-hover:text-primary transition-colors duration-300">
                        {product.name}
                      </h3>
                      <p className="text-xs text-muted-foreground font-medium">
                        {product.category}
                      </p>
                    </div>
                    <button
                      onClick={() => toggleFavorite(product.id)}
                      className="p-2 hover:bg-primary/10 rounded-full transition-all duration-300 transform hover:scale-110"
                    >
                      <Heart
                        className={`w-5 h-5 transition-all duration-300 ${
                          favorites.has(product.id)
                            ? "fill-primary text-primary scale-110"
                            : "text-muted-foreground"
                        }`}
                      />
                    </button>
                  </div>

                  <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">
                    {product.description}
                  </p>

                  {/* Rating */}
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Star className="w-3 h-3 fill-primary text-primary" />
                    <span>({product.reviews} تقييم)</span>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-border/20">
                    <span className="text-2xl font-bold bg-gradient-to-r from-primary to-muted bg-clip-text text-transparent">
                      {product.price.toFixed(2)} د.ك
                    </span>
                  </div>
                </div>

                {/* Decorative elements */}
                <div className="absolute top-2 right-2 w-10 h-10 bg-primary/10 rounded-full blur-md opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              </div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-16">
              <p className="text-xl text-muted-foreground">لم نجد منتجات مطابقة للبحث</p>
            </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section id="about" className="py-24 bg-gradient-to-br from-primary/5 via-transparent to-muted/5 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
        </div>

        <div className="container relative z-10">
          <div className="grid md:grid-cols-3 gap-12">
            {[
              { icon: "🌱", title: "مكونات طبيعية", desc: "نستخدم أفضل المكونات الطبيعية والعضوية" },
              { icon: "👨‍🍳", title: "صنع حرفي", desc: "كل كوب يتم تحضيره بعناية فائقة" },
              { icon: "⚡", title: "جودة عالية", desc: "نضمن أفضل جودة في كل مشروب ومخبوزة" },
            ].map((feature, idx) => (
              <div
                key={idx}
                className="text-center space-y-4 p-8 rounded-2xl bg-white/5 backdrop-blur-sm border border-border/20 hover:border-primary/30 transition-all duration-300 group hover:shadow-lg hover:-translate-y-2"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-primary/20 to-muted/20 rounded-full flex items-center justify-center mx-auto group-hover:scale-110 transition-transform duration-300">
                  <span className="text-3xl">{feature.icon}</span>
                </div>
                <h3 className="text-xl font-bold text-foreground">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground/3 border-t border-border/20 py-16 backdrop-blur-sm">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-muted flex items-center justify-center">
                  <span className="text-lg font-bold text-primary-foreground">K</span>
                </div>
                <h4 className="font-bold text-foreground">knof</h4>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                مقهى فاخر متخصص في تقديم أفضل المشروبات والمخبوزات الحرفية
              </p>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">المنيو</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors duration-300">المشروبات</a></li>
                <li><a href="#" className="hover:text-primary transition-colors duration-300">المخبوزات</a></li>
                <li><a href="#" className="hover:text-primary transition-colors duration-300">العروض الخاصة</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">التواصل</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors duration-300">البريد الإلكتروني</a></li>
                <li><a href="#" className="hover:text-primary transition-colors duration-300">الهاتف</a></li>
                <li><a href="#" className="hover:text-primary transition-colors duration-300">العنوان</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">تابعنا</h4>
              <a
                href="https://www.instagram.com/knof.kw?igsh=MXhiczV2aTU5eHhuNw=="
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center hover:bg-gradient-to-r hover:from-primary hover:to-muted hover:text-primary-foreground transition-all duration-300 transform hover:scale-110 inline-flex"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>
          <div className="border-t border-border/20 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 knof - جميع الحقوق محفوظة | صُنع بعناية فائقة</p>
          </div>
        </div>
      </footer>

      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .delay-1000 {
          animation-delay: 1s;
        }
      `}</style>
    </div>
  );
}
